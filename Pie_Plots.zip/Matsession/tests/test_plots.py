import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.testing.decorators import image_comparison

@image_comparison(baseline_images=['Iris_Sepal_Length_BarPlot'],extensions=['png'])
def test_barplot_of_iris_sepal_length():

    # Write your functionality below


@image_comparison(baseline_images=['Iris_Measurements_BarPlot'],extensions=['png'])
def test_barplot_of_iris_measurements():

    # Write your functionality below


@image_comparison(baseline_images=['Iris_Petal_Length_BarPlot'],extensions=['png'])
def test_hbarplot_of_iris_petal_length():

    # Write your functionality below
  
